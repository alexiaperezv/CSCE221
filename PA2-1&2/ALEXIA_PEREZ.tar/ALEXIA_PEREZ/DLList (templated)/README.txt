README File for Assignment 2 - The Class DLList (part 2)

Alexia Perez, 127008512, CSCE 221-506, alexia_perezv, alexia_perezv@tamu.edu
---------------------------------------------------------------------------------------------------------
I certify that I have listed all the sources that I used to develop the solutions and code to the submitted work.
	On my honor as an Aggie, I have neither given nor received any unauthorized help on this academic work.
Alexia Perez
February 25th, 2020
---------------------------------------------------------------------------------------------------------
Aside from a few discussions with Peer Teachers, the only other outside resource I used was: 

https://www.geeksforgeeks.org/

I used this resource to read documentation about the use of templated classes and some other small
details such as definitons for the different types of constructors and their use, etc.
 
---------------------------------------------------------------------------------------------------------
No issues found with the code submitted.
---------------------------------------------------------------------------------------------------------
The program: 

Everything is the "same" as the DLList.cpp functions except in this case, the function types are templated, so that we can use lists that contain characters, strings, integers, or other types of data. The main (test file) is also almost the same, except I created 3 data types with a value assiged to them and manipulated the doubly linked lists by inserting/removing these data types in order to prove that the templated functions truly work with any data type. 

---------------------------------------------------------------------------------------------------------

The program was tested using the Cygwin terminal and a make file that Professor Leyk provided. Once it was completed and tested, I used the Putty terminal to make sure that it would work on the TAs computer.

---------------------------------------------------------------------------------------------------------
I ran the program a total of 10 times once I completed it, to ensure that all functions worked properly, and that the program outputted the right information each time. All tests passed.




